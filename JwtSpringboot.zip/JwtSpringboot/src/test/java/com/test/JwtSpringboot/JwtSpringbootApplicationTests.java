package com.test.JwtSpringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
