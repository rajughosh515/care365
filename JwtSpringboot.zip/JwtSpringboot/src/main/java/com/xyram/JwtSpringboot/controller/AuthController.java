package com.xyram.JwtSpringboot.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.xyram.JwtSpringboot.model.PasswordChg;
import com.xyram.JwtSpringboot.model.User;
import io.swagger.annotations.ApiOperation;


@RestController
public class AuthController {
	
	@ApiOperation(value="valid token details")
	@RequestMapping(method = RequestMethod.GET, value = "/api/v1/auth/validate-token")
	public String validateToken() {
		return "Details will add shortly";
	}
	
	@ApiOperation(value="user login details")
	@RequestMapping(method = RequestMethod.POST, value = "/api/v1/auth/login")
	public User login(@RequestBody User user) {
		
		String loginId=user.getLoginId();
		System.out.println("login :: "+loginId);
		String password =user.getPassword();
		System.out.println("password :: "+password);
		User user1=new User();
		if(loginId.equalsIgnoreCase("raju") && password.equalsIgnoreCase("ghosh")) {
			
			user1.setMessage("Success");
			user1.setRoleId(111);
			
			return user1;
		}		
		user1.setMessage("failure");
		return user1;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/api/v1/auth/logout")
	public User logOut(@RequestBody User user) {
		
		String loginId=user.getLoginId();
		System.out.println("login :: "+loginId);
		String password =user.getPassword();
		System.out.println("password :: "+password);
		User user1=new User();
		if(loginId.equalsIgnoreCase("raju") && password.equalsIgnoreCase("ghosh")) {
			
			user1.setMessage("Success");
			user1.setRoleId(111);
			
			return user1;
		}		
		user1.setMessage("failure");
		return user1;
	}
	
	@ApiOperation(value="user password reset details")
	@RequestMapping(method = RequestMethod.POST, value = "/api/v1/auth/resetPassword")
	public PasswordChg resetPassword(@RequestBody PasswordChg pChg) {
		
		String loginID=pChg.getLoginId();
		String oldPwd=pChg.getOldPwd();
		String newPwd=pChg.getNewPwd();
		String reNewPwd=pChg.getReNewPwd();
		PasswordChg paschg = new PasswordChg();			
		paschg.setOldPwd("ghosh");
		
		if(loginID.equalsIgnoreCase("Raju") && oldPwd.equalsIgnoreCase(paschg.getOldPwd()) &&newPwd.equalsIgnoreCase(reNewPwd)) {
			paschg.setNewPwd(newPwd);			
			paschg.setMessage("Password changed successfully");
			return paschg;
		}
		
		paschg.setMessage("Please Enter valid details");
		return paschg;
	}
	
	
	

}
