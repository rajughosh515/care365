package com.xyram.care365;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Care365Application {

	public static void main(String[] args) {
		SpringApplication.run(Care365Application.class, args);
	}

}
