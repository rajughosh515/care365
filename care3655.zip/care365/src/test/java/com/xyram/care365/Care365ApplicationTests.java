package com.xyram.care365;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Care365ApplicationTests {

	@Test
	void contextLoads() {
	}

}
